
    var g_lastPreviewType = 'table';
    var g_colorizeStrategy = 'hex';
    
    let g_toast_delay = 1000;

    const template_appSVGbackground = `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='25' height='25' viewBox='0 0 25 25'%3E%3Cdefs%3E%3Cstyle%3E .prefix__cls-2%7Bfill:none;stroke: %2329263d;stroke-linecap:round;stroke-linejoin:round;stroke-width:1px%7D %3C/style%3E%3C/defs%3E%3Cg id='prefix__Group_4633' data-name='Group 4633' transform='translate(-322.5 -389.5)'%3E%3Cpath id='prefix__Rectangle_3303' d='M0 0H24V24H0z' data-name='Rectangle 3303' transform='translate(323 390)' style='opacity:0;fill:none;stroke:%2329263d'/%3E%3Cg id='prefix__Group_4632' data-name='Group 4632' transform='translate(-691.281 173.443)'%3E%3Cpath id='prefix__Path_5389' d='M1029.558 230.005h1.447a3.286 3.286 0 0 1 3.276 3.276 3.286 3.286 0 0 1-3.276 3.277h-9.448a3.286 3.286 0 0 1-3.276-3.277' class='prefix__cls-2' data-name='Path 5389' style='&%2310; fill: %23{hex3};&%2310;'/%3E%3Cpath id='prefix__Path_5390' d='M1024.9 225.306l1.017-1.018a3.286 3.286 0 0 1 4.633 0 3.284 3.284 0 0 1 0 4.633l-6.68 6.681a3.286 3.286 0 0 1-4.633 0' class='prefix__cls-2' data-name='Path 5390' style='&%2310; fill: %23{hex2};&%2310;'/%3E%3Crect id='prefix__Rectangle_3305' width='6.552' height='16' class='prefix__cls-2' data-name='Rectangle 3305' rx='3.276' transform='translate(1018.281 220.558)' style='&%2310; fill: %23{hex1};&%2310;'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E`;

    col_ChannelMixer = function( colorChannelA, colorChannelB, amountToMix )
    {
        var channelA = colorChannelA * amountToMix;
        var channelB = colorChannelB * ( 1 - amountToMix );

        return parseInt(channelA+channelB);
    }

    col_MixRBGA = function( rgbA, rgbB, amountToMix, opac )
    {
        var r = col_ChannelMixer( rgbA[0], rgbB[0], amountToMix );
        var g = col_ChannelMixer( rgbA[1], rgbB[1], amountToMix );
        var b = col_ChannelMixer( rgbA[2], rgbB[2], amountToMix );
        var a = opac ? parseFloat( parseFloat(opac).toFixed(2).toString() ) : 1;

        return "rgba("+r+","+g+","+b+","+a+")";
    }

    col_MixHEX = function( rgbA, rgbB, amountToMix, a )
    {
        var r = col_ChannelMixer( rgbA[0], rgbB[0], amountToMix );
        var b = col_ChannelMixer( rgbA[2], rgbB[2], amountToMix );
        var g = col_ChannelMixer( rgbA[1], rgbB[1], amountToMix );
        var newColor = col_rgbToHex( r, b, g );

        if ( a < 1  )
        {
            var newR = col_ChannelMixer( r, 255, a );
            var newB = col_ChannelMixer( b, 255, a );
            var newG = col_ChannelMixer( g, 255, a );

            newColor = col_rgbToHex( newR, newB, newG );
        }

        return newColor;
    }

    col_rgbToHex = function(r,b,g) 
    {
        var hex = "";

        componentFromStr = function(numStr, percent) {
            var num = Math.max(0, parseInt(numStr, 10));
            return percent ? Math.floor(255 * Math.min(100, num) / 100) : Math.min(255, num);
        };

        r = componentFromStr( r, "" );
        g = componentFromStr( g, "" );
        b = componentFromStr( b, "" );

        hex = "0x" + (0x1000000 + (r << 16) + (g << 8) + b).toString(16).slice(1);

        return hex.replace('0x','#').toUpperCase() ;//replace added by Greg
    }

    col_hexToRgb = function(hex)
    {
        var c, ret = [];
        if ( /^#([A-Fa-f0-9]{3}){1,2}$/.test( hex ) )
        {
            c= hex.substring(1).split('');
            if(c.length== 3){
                c= [c[0], c[0], c[1], c[1], c[2], c[2]];
            }
            c= '0x'+c.join('');
            return ('rgb('+[(c>>16)&255, (c>>8)&255, c&255].join(',')+')');
        }
        throw new Error('Bad Hex: ' + hex);
    }

    col_hexToRgbArray = function(hex)
    {
        var c, ret = [];
        if ( /^#([A-Fa-f0-9]{3}){1,2}$/.test( hex ) )
        {
            c= hex.substring(1).split('');
            if(c.length== 3){
                c= [c[0], c[0], c[1], c[1], c[2], c[2]];
            }
            c= '0x'+c.join('');
            return (''+[(c>>16)&255, (c>>8)&255, c&255].join(',')+'').split( ',' );
        }
        throw new Error('Bad Hex: ' + hex);
    }

    col_hexToRgbA = function(hex)
    {
        var c;
        if ( /^#([A-Fa-f0-9]{3}){1,2}$/.test( hex ) )
        {
            c= hex.substring(1).split('');
            if(c.length== 3){
                c= [c[0], c[0], c[1], c[1], c[2], c[2]];
            }
            c= '0x'+c.join('');
            return (''+[(c>>16)&255, (c>>8)&255, c&255].join(',')+'');
        }
        throw new Error('Bad Hex: ' + hex);
    }

    col_hexToHSL = function(hex)
    {
        var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);

        var r = parseInt(result[1], 16);
        var g = parseInt(result[2], 16);
        var b = parseInt(result[3], 16);

        r /= 255, g /= 255, b /= 255;
        var max = Math.max(r, g, b), min = Math.min(r, g, b);
        var h, s, l = (max + min) / 2;

        if(max == min){
            h = s = 0; // achromatic
        } else {
            var d = max - min;
            s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
            switch(max) {
                case r: h = (g - b) / d + (g < b ? 6 : 0); break;
                case g: h = (b - r) / d + 2; break;
                case b: h = (r - g) / d + 4; break;
            }
            h /= 6;
        }

        s = s*100;
        s = Math.round(s);
        l = l*100;
        l = Math.round(l);
        h = Math.round(360*h);

        return 'hsl(' + h + ',' + s + '%,' + l + '%)';
    }


    createColorScheme = function( colStart, colEnd, fadeCenterOpac, colBlocks, callback )
    {
        var ret = { 'config': { 'startColor': colStart, 'endColor': colEnd, 'centerOpacity': fadeCenterOpac, 'rows': colBlocks }, 'result': [] };
        var colStartMix = col_hexToRgbArray( colStart );
        var colEndMix = col_hexToRgbArray( colEnd );

        var halfWay = Math.floor( colBlocks / 2 );
        var oddNumber_colorCalc = ( Math.ceil( colBlocks / 2 ) !== Math.floor( colBlocks / 2 ) );

        var AtoB_frac = ( 1 / (colBlocks - 1) );
        var opacFrac_denom = oddNumber_colorCalc ? ( halfWay * 2 ) : colBlocks - 2;
        var opac_frac = ( 1 - fadeCenterOpac ) / ( opacFrac_denom / 2 );
        var opac = 1, AtoB_scale = 1; // color blend scale (from color A to color B); 1 = colorA strongest, 0 = colorB strongest
        var blend_Hex;

        blend_Hex = col_MixHEX( colStartMix, colEndMix, 1, opac );

        /* STARTING COLOR: first block */
        var colRule = { 
            'id': 1,
            'hex': blend_Hex, 
            'rgb': col_hexToRgb( blend_Hex ),
            'rgba': col_MixRBGA( colStartMix, colEndMix, 1, opac ),
            'hsl': col_hexToHSL( blend_Hex ),
            'blend': 1, 
            'opacity': opac
        };

        ret.result.push( colRule );

        for ( var i = 2; i <= halfWay; i++ )
        {
            AtoB_scale -= AtoB_frac;
            opac -= opac_frac;
            blend_Hex = col_MixHEX( colStartMix, colEndMix, AtoB_scale, opac );

            var colRule = { 
                'id': i,
                'hex': blend_Hex, 
                'rgb': col_hexToRgb( blend_Hex ),
                'rgba': col_MixRBGA( colStartMix, colEndMix, AtoB_scale, opac ),
                'hsl': col_hexToHSL( blend_Hex ),
                'blend': AtoB_scale, 
                'opacity': opac
            };

            ret.result.push( colRule );
        }

        if ( oddNumber_colorCalc ) opac -= opac_frac;
        
        for ( var i = (halfWay+1); i < colBlocks; i++ )
        {
            AtoB_scale -= AtoB_frac;
            blend_Hex = col_MixHEX( colStartMix, colEndMix, AtoB_scale, opac );

            var colRule = { 
                'id': i,
                'hex': blend_Hex, 
                'rgb': col_hexToRgb( blend_Hex ),
                'rgba': col_MixRBGA( colStartMix, colEndMix, AtoB_scale, opac ),
                'hsl': col_hexToHSL( blend_Hex ),
                'blend': AtoB_scale, 
                'opacity': opac
            };

            ret.result.push( colRule );

            opac += opac_frac;
        }

        blend_Hex = col_MixHEX( colStartMix, colEndMix, 0, 1 );

        /* ENDING COLOR: final block */
        var colRule = { 
                'id': colBlocks,
                'hex': blend_Hex, 
                'rgb': col_hexToRgb( blend_Hex ),
                'rgba': col_MixRBGA( colStartMix, colEndMix, 0, 1 ),
                'hsl': col_hexToHSL( blend_Hex ),
                'blend': 0, 
                'opacity': 1
        };

        ret.result.push( colRule );

        if ( callback ) callback( ret );
        else return ret;

    };


    emptyTarget = function( callback )
    {
        var targ = $( '.targetColorScheme' );
        targ.empty();

        callback( targ );
    }

    getTriangleSVG = function( bgcolor )
    {
        return '<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" style="fill: none;"><polygon fill="' + bgcolor + '" points="12 0, 24 24, 0 24"/></svg>';
    }

    createPreviewTableContainer = function( callback )
    {
        var targ = $( '.targetColorScheme' );
        targ.empty();

        var dv = $( '<div />' );
        targ.append( dv );

        var tbl = $( '<table />' );
        var tr = $( '<tr />' );

        dv.append( tbl );
        tbl.append( tr );

        //var td = $( '<td class="col">#</td>' );
        //tr.append( td );

        var td = $( '<td class="col">HEX</td>' );
        tr.append( td );

        var td = $( '<td class="col">RGB</td>' );
        tr.append( td );

        //var td = $( '<td class="col">RGBA</td>' );
        //tr.append( td );

        var td = $( '<td class="col">HSL</td>' );
        tr.append( td );

        //var td = $( '<td class="col">blend</td>' );
        //tr.append( td );

        //var td = $( '<td class="col">opacity</td>' );
        //tr.append( td );

        //var td = $( '<td class="col">rangeMIN</td>' );
        //tr.append( td );

        //var td = $( '<td class="col">rangeMAX</td>' );
        //tr.append( td );

        //var td = $( '<td>&nbsp;&nbsp;&nbsp;</td>' );
        //tr.append( td );

        callback( tbl );

    }

    createPreviewTableRow = function( tbl, row )
    {
        var tr = $( '<tr />' );
        tbl.append( tr );

        if ( g_lastPreviewType == 'table' )
        {
            var td = $( '<td class="hex" style="background-Color:' + row.hex + ';">' + row.hex + '</td>' );
        }
        else
        {
            //var td = $( '<td class="hex"><div class="circle" style="background-Color:' + row.hex + ';width:18px;">&nbsp;</div></td>' );
            var td = $( '<td class="hex"></td>' );
            var cir = $( '<div class="circle" style="background-Color:' + row.hex + ';width:18px;">&nbsp;</div>' );
            var tri = $( '<div class="triangle">' + getTriangleSVG( row.hex ) + '</div>' );
            var sqr = $( '<div class="square" style="background-Color:' + row.hex + ';">&nbsp;</div>' );

            td.append( cir, tri, sqr )
        }
        tr.append( td );

            $( td ).on( 'mouseover', function(){
                var col = $( this );
                col.css( 'filter', 'drop-shadow(3px 1px 5px #808080)' );
            });

            $( td ).on( 'click', function(){
                util_copyToClipboard( row.hex );
                $( '.paletteColor' ).val( row.hex );
            });

            $( td ).on( 'mouseout', function(){
                var col = $( this );
                col.css( 'filter', 'none' );
            });


            if ( g_lastPreviewType == 'table' )
            {
                var td = $( '<td class="rgb" style="background-Color:' + row.rgb + ';">' + row.rgb + '</td>' );
            }
            else
            {
                var td = $( '<td class="rgb"></td>' );
                var cir = $( '<div class="circle" style="background-Color:' + row.rgb + ';width:18px;">&nbsp;</div>' );
                var tri = $( '<div class="triangle">' + getTriangleSVG( row.rgb ) + '</div>' );
                var sqr = $( '<div class="square" style="background-Color:' + row.rgb + ';">&nbsp;</div>' );

                td.append( cir, tri, sqr )
            }

            tr.append( td );

            $( td ).on( 'mouseover', function(){
                var col = $( this );
                col.css( 'filter', 'drop-shadow(3px 1px 5px #808080)' );
            });

            $( td ).on( 'click', function(){
                util_copyToClipboard( row.rgb );
                $( '.paletteColor' ).val( row.hex );
            });

            $( td ).on( 'mouseout', function(){
                var col = $( this );
                col.css( 'filter', 'none' );
            });

        /*var td = $( '<td style="background-Color:' + row.rgba + ';min-width:30px;cursor:pointer;">&nbsp;' + row.rgba + '&nbsp;</td>' );
        tr.append( td );

            $( td ).on( 'mouseover', function(){
                var col = $( this );
                col.css( 'filter', 'drop-shadow(3px 1px 5px #808080)' );
            });

            $( td ).on( 'click', function(){
                util_copyToClipboard( row.rgba );
                $( '.paletteColor' ).val( row.hex );
            });

            $( td ).on( 'mouseout', function(){
                var col = $( this );
                col.css( 'filter', 'none' );
            });*/

            if ( g_lastPreviewType == 'table' )
            {
                var td = $( '<td class="hsl" style="background-Color:' + row.hsl + ';">' + row.hsl + '</td>' );
            }
            else
            {
                //var td = $( '<td class="hsl"><div class="circle" style="background-Color:' + row.hsl + ';width:18px;">&nbsp;</div></td>' );
                var td = $( '<td class="hsl"></td>' );
                var cir = $( '<div class="circle" style="background-Color:' + row.hsl + ';width:18px;">&nbsp;</div>' );
                var tri = $( '<div class="triangle">' + getTriangleSVG( row.hsl ) + '</div>' );
                var sqr = $( '<div class="square" style="background-Color:' + row.hsl + ';">&nbsp;</div>' );

                td.append( cir, tri, sqr )
            }
            tr.append( td );

            $( td ).on( 'mouseover', function(){
                var col = $( this );
                col.css( 'filter', 'drop-shadow(3px 1px 5px #808080)' );
            });

            $( td ).on( 'click', function(){
                util_copyToClipboard( row.hsl );
                $( '.paletteColor' ).val( row.hex );
            });

            $( td ).on( 'mouseout', function(){
                var col = $( this );
                col.css( 'filter', 'none' );
            });

        //var td = $( '<td style="">&nbsp;' + util_roundNumber( row.blend * 100, 1 ) + '%&nbsp;</td>' );
        //tr.append( td );

        //var td = $( '<td style="">&nbsp;' + util_roundNumber( row.opacity, 3 ) + '&nbsp;</td>' );
        //tr.append( td );

        //var td = $( '<td>&nbsp;</td>' );
        //tr.append( td );
    }

    createPreviewCodeBlock = function( targ, content )
    {
        var pre = $( '<pre />' );
        var code = $( '<code />' );

        targ.append( pre );
        pre.append( code );

        code.html( content );

        pre.on( 'click', function(){
            util_copyToClipboard( content );
        });
    }

    createPreviewShapeByClassName = function( dv, classType, itm, arr )
    {
        // play area, for visualizing circles, squares, dots, blocks; very randomized + only added for visual previewing of shapes
        var posRndGroup = [ 'dots', 'blocks' ];
        var availableArea = $( 'div.output' ).width() < $( 'div.output' ).height() ? $( 'div.output' ).width() : $( 'div.output' ).height();
        var percOfAll = (itm+1) / arr.length;
        var offSetArea = availableArea / arr.length; //30;
        var sizeOffset = availableArea * 0.8; //(screen.width / 2 / arr.length);

        var scaleThis = posRndGroup.includes( classType ) ? offSetArea : sizeOffset * percOfAll;
        var spacerY = posRndGroup.includes( classType ) ? ( Math.random( availableArea ) * sizeOffset ) - (offSetArea/10) : 0; 
        var spacerX = posRndGroup.includes( classType ) ? Math.random( availableArea ) * $( 'div.output' ).width() * 0.8 : ( sizeOffset / 2 ) - ( ( sizeOffset / 2 ) * percOfAll);
        var bgGradient = posRndGroup.includes( classType ) ? 'all' : 'last';

        var row = arr[ itm ];
        var fill = row[ g_colorizeStrategy ];
        var baseWidth = ( $( 'div.output' ).width() ) - ( $( 'div.output' ).width() / 5 ) + 'px'; 
        var dvShape = $( '<div class="' + classType + ' colorShape" style="z-index:' + (9999-itm) + ';position:absolute;left:' + (18 + spacerX) + 'px;top:' + (70 + spacerY) + 'px;width: ' + scaleThis + 'px;height:' + scaleThis + 'px;background-color:' + fill + ';" />' );

        dvShape.html( '&nbsp;' );
        dvShape.attr( 'rgba', row.rgba );
        dvShape.attr( 'hex', row.hex );
        dvShape.attr( 'hsl', row.hsl );

        dv.append( dvShape );

            //if ( ! posRndGroup.includes( classType ) )
            {
                $( dvShape ).on( 'mouseover', function(){
                    var col = $( this );
                    col.css( 'filter', 'drop-shadow(3px 1px 4px #808080)' );
                });
            }


            $( dvShape ).on( 'click', function(){
                util_copyToClipboard( $( this ).attr( g_colorizeStrategy ) );
                $( '.paletteColor' ).val( $( this ).attr( 'hex' ) );
            });

            //if ( bgGradient === 'last' )
            {
                $( dvShape ).on( 'mouseout', function(){
                    var col = $( this );
                    col.css( 'filter', 'none' );
                });
            }

        if ( bgGradient === 'last' && itm === arr.length -1 )
        {
            $( dvShape ).off( 'mouseover' );
            $( dvShape ).off( 'mouseout' );
            $( dvShape ).css( 'filter', 'drop-shadow(3px 1px 4px #808080)' );
        }

        if ( posRndGroup.includes( classType ) )
        {
            $( dvShape ).css( 'filter', 'drop-shadow(1px 1px 2px #808080)' );
            $( dvShape ).off( 'mouseover' );
            $( dvShape ).off( 'mouseout' );
        }
        /*else if ( ! posRndGroup.includes( classType ) )
        {
            $( dvShape ).css( 'filter', 'drop-shadow(3px 1px 4px #808080)' );
        }

        if ( bgGradient === 'all' )
        {
            $( dvShape ).css( 'filter', 'drop-shadow(3px 1px 4px #808080)' );
        }*/
    }


    saveLastValues = function( colStart, colEnd, rows, opac )
    {
        localStorage.setItem( 'colorBlend_start', colStart );
        localStorage.setItem( 'colorBlend_end', colEnd );
        localStorage.setItem( 'colorBlend_rows', rows );
        localStorage.setItem( 'colorBlend_opacity', opac );
    }


    createPaletteItem = function()
    {
        var cols = [];
        var col = $( '.paletteColor').val();
        var pal = col_hexToRgbA( col ).split(',');

        if ( localStorage.getItem( 'colorBlend_palettes' ) )
        {
            cols = JSON.parse( localStorage.getItem( 'colorBlend_palettes' ) );
        }

        cols.push( col );
        
        var tbl = $( '.palletes' ).find( 'table' );

        blend = col_MixRBGA( pal, pal, 1, 1 );
        blend_Hex = col_MixHEX( pal, pal, 1, 1 );

        createPaletteItemRow( tbl, blend,blend_Hex );

        localStorage.setItem( 'colorBlend_palettes', JSON.stringify( cols ) );

    }

    createPaletteItemRow = function( tbl, blend, blend_Hex )
    {
        var uniqueID = util_generateRandomId( 6 );
        var tr = $( '<tr class="palRow" id="tr_' + uniqueID + '" />' );

        tbl.append( tr );
        var td = $( '<td />' );
        tr.append( td );

        var col = $( '<div class="colorPalette" style="background-Color:' + blend_Hex + '" />' );
        td.append( col );

        col.on( 'click',function( event ) {

            var col = tr.find( 'input.paletteColor' ).val();
            var startCol = $( 'input.startColor' ).val();

            $( 'input.endColor' ).val( startCol );
            $( 'input.startColor' ).val( blend_Hex );

            run_Blend();

        });

        var td = $( '<td class="flexRow" />' );

        var del = $( '<div class="delSVG" idx="' + $( '.palletes' ).find( 'table' ).find( 'tr.palRow' ).length + '" />' );
        td.append( del );

        del.on( 'click',function( event ) {

            var cols = JSON.parse( localStorage.getItem( 'colorBlend_palettes' ) );
            var col = tr.find( 'input.color' ).val();
            var allTrs = $( 'div.palletes' ).find( 'table>tbody>tr' );

            allTrs.each( function( idx, tr ){ 

                if ( $( tr ).attr( 'id' ) == "tr_" + uniqueID  )
                {
                    colIdx = idx -2;
                    cols.splice( colIdx, 1 );
                    localStorage.setItem( 'colorBlend_palettes', JSON.stringify( cols ) );
                    tr.remove();
                }

            });

        });

        createPaletteItemRow_events( tr );

        tr.append( td );
    }

    createPaletteItemRow_events = function( tr )
    {
        $( tr ).on( 'mouseover', function(){

            var col = $( this ).find( '.colorPalette' );
            col.css( 'filter', 'drop-shadow(3px 1px 5px #808080)' );

            var del = $( this ).find( '.delSVG' );
            del.css( 'display', 'block' );

        });

        $( tr ).on( 'mouseout', function(){

            var col = $( this ).find( '.colorPalette' );
            col.css( 'filter', 'drop-shadow(3px 1px 4px #808080)' );

            var del = $( this ).find( '.delSVG' );
            del.css( 'display', 'none' );

        });
    };


    util_copyToClipboard = function( text )
    {
        if ( navigator.clipboard ) 
        {
            navigator.clipboard.writeText( text );
            //ui_notificationPopup( 'copied to clipboard', 'notifLight', 'right', 'top' )
            Toastify({

                text: 'copied to clipboard',
                duration: g_toast_delay,
                close: true,
                style: {
                    background: 'linear-gradient(to right, #3B3B3B, #265047)',
                }
    
            }).showToast();
        }
    };

    util_roundNumber = function( num, decimals )
    {
        num = (num + '' )
            .replace(/[^0-9+\-Ee.]/g, '' );
        var n = !isFinite(+num) ? 0 : +num,
            prec = !isFinite(+decimals) ? 0 : Math.abs(decimals),
            sep = ',',
            dec = '.',
            s = '',
            toFixedFix = function (n, prec) {
                var k = Math.pow(10, prec);
                return '' + (Math.round(n * k) / k)
                    .toFixed(prec);
            };

        s = (prec ? toFixedFix(n, prec) : '' + Math.round(n))
            .split( '.' );
        if (s[0].length > 3) {
            s[0] = s[0].replace(/\B(?=(?:\d{3})+(?!\d))/g, sep);
        }
        if ((s[1] || '' )
            .length < prec) {
            s[1] = s[1] || '';
            s[1] += new Array(prec - s[1].length + 1)
                .join( '0' );
        }
        var repl=''; for ( var i = 1; i <= decimals; i ++ ){ repl += '0' }; //remove consecutive 'decimal' zeroes that match length decimals
        return s.join(dec).replace('.' + repl,'');
    }

    util_generateRandomId = function( len )
    {
        var id = '';
        var charSet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        var id_size = 12;

        if ( len ) id_size = len;

        for (var i = 1; i <= id_size; i++) 
        {
            var randPos = Math.floor( Math.random() * charSet.length );
            id += charSet[ randPos ];
        }
        
        return id;
    }


    refresh_previewShapeColors = function()
    {
        var shapes = $( 'div.colorShape' );

        $.each( shapes, function( i, shape ){

            $( shape ).css( 'background-color', $( shape ).attr( g_colorizeStrategy ) );

        });
    }

    run_createEvents = function()
    {
        var rows = $( '.palRow' );

        $.each( rows, function( e, tr ){

            createPaletteItemRow_events( tr );

        });

        $( '.flipIconSVG' ).on( 'click', function(){

            var start = $( '.startColor' ).val();
            var end = $( '.endColor' ).val();

            $( '.startColor' ).val( end );
            $( '.endColor' ).val( start );

            run_Blend();

        });

        $( '.startColor' ).on( 'change', function(){

            run_Blend();

        });

        $( '.endColor' ).on( 'change', function(){

            run_Blend();

        });

        $( '.colBlocks' ).on( 'change', function(){

            run_Blend();

        });
        
        $( '.colBlocks' ).on( 'wheel', function(e,a){

            var val = parseFloat( $( '.colBlocks' ).val() );

            if ( e.originalEvent.deltaY < 0 ) val+=1;
            if ( e.originalEvent.deltaY > 0 ) val-=1;

            $( '.colBlocks' ).val( val );

            run_Blend();

        });

        $( '.opac' ).on( 'change', function(){

            $('.opacText').html( $( this ).val() );

            run_Blend();

        });
        
        $( '.addPalette' ).on( 'click', function(){

            createPaletteItem()

        });

        if ( window.EyeDropper !== undefined )
        {
            $( '.actionColorPicker' ).on( 'click', function(){

                let eyeDropper = new EyeDropper();

                // Enter eyedropper mode
                eyeDropper.open()
                .then(colorSelectionResult => {

                    // returns hex color value (#RRGGBB) of the selected pixel
                    //console.log(colorSelectionResult.sRGBHex);
                    var start = $( '.startColor' ).val();
                    var end = $( '.endColor' ).val();
        
                    $( '.startColor' ).val( colorSelectionResult.sRGBHex );
                    $( '.endColor' ).val( start );

                    run_Blend();

                })
                .catch(error => {
                    // handle the user choosing to exit eyedropper mode without a selection
                });

            });
        }
        else
        {
            $( '.actionColorPicker' ).hide();
        }


        var tabs = $( 'div.button' );

        $.each( tabs, function( e, tab ){

            $( tab ).on( 'click', function(){

                run_Blend( $( tab ).html() );

            });

        });


        $( '.colorField' ).on( 'change', function(){

            g_colorizeStrategy = $( this ).val();

            refresh_previewShapeColors();

        });


        $( 'input.startColor' ).on( 'contextmenu', function(){

            navigator.clipboard
                .readText()
                .then(( copiedText ) => {
                    if ( copiedText && copiedText.toString().length && copiedText.toString().indexOf( '#' ) === 0 )
                    {
                        $( 'input.startColor' ).val( copiedText );
                        
                        run_Blend();
                    }
                });

            return false;
            
        });

        $( 'input.endColor' ).on( 'contextmenu', function(){

            navigator.clipboard
                .readText()
                .then(( copiedText ) => {
                    if ( copiedText && copiedText.toString().length && copiedText.toString().indexOf( '#' ) === 0 )
                    {
                        $( 'input.endColor' ).val( copiedText );

                        run_Blend();
                    }
                });

            return false;

        });

    };

    run_Blend = function( outputOpt, callback )
    {
        var colStart = $( '.startColor' ).val();
        var colEnd = $( '.endColor' ).val();
        var fadeCenterOpac = $( '.opac' ).val();
        var colBlocks = $( '.colBlocks' ).val();

        saveLastValues( colStart, colEnd, colBlocks, fadeCenterOpac );

        var scheme = createColorScheme( colStart, colEnd, fadeCenterOpac, colBlocks );
        var type = ( outputOpt === undefined ) ? g_lastPreviewType : outputOpt;

        g_lastPreviewType = type;

        if ( type == 'table' || type == 'shapes' )
        {
            createPreviewTableContainer( function( tbl ){

                var output = scheme.result;

                for ( var i = 0; i < output.length; i++ )
                {
                    createPreviewTableRow( tbl, output[i] );

                    update_ui( scheme, callback );
                }

            });
        }
        else if ( type === 'code' )
        {
            emptyTarget( function( dv ){

                createPreviewCodeBlock( dv, JSON.stringify( scheme.result, null, 4 ) );

                update_ui( scheme, callback );

            });
        }
        else if ( type === 'array' )
        {
            emptyTarget( function( dv ){

                var hex = scheme.result.map(function(obj, idx, arr){ return obj[ 'hex' ]; });
                var rgb = scheme.result.map(function(obj, idx, arr){ return obj[ 'rgb' ]; });
                var hsl = scheme.result.map(function(obj, idx, arr){ return obj[ 'hsl' ]; });

                createPreviewCodeBlock( dv, JSON.stringify( { 'hex': hex, 'rgb': rgb, 'hsl': hsl }, null, 4 ) );

                update_ui( scheme, callback );

            });
        }
        else if ( type === 'custom' )
        {
            /* STORED PALETTES */
            if ( localStorage.getItem( 'colorBlend_palettes' ) )
            {
                emptyTarget( function( dv ){

                    var palettes = JSON.parse( localStorage.getItem( 'colorBlend_palettes' ) );
                    var tbl = $( '<table class="palettes">' );

                    dv.append( tbl );
    
                    for ( var i = 0; i < palettes.length; i++ )
                    {
                        var pal = col_hexToRgbA( palettes[ i ] ).split(',');
                        var blend = col_MixRBGA( pal, pal, 0.99, 1 );
                        var blend_Hex = col_MixHEX( pal, pal, 0.99, 1 );
    
                        createPaletteItemRow( tbl, blend,blend_Hex );
                    }

                    update_ui( scheme, callback );

                });
            }
        }
        else
        {
            emptyTarget( function( dv ){

                var output = scheme.result;
                var posRndGroup = [ 'dots', 'blocks' ];

                for ( var i = 0; i < output.length; i++ )
                {
                    createPreviewShapeByClassName( dv, type, i, output );
                }

                if ( posRndGroup.includes( type ) )
                {
                    //run a scond time

                    for ( var i = 0; i < output.length; i++ )  createPreviewShapeByClassName( dv, type, i, output );

                    for ( var i = 0; i < output.length; i++ )  createPreviewShapeByClassName( dv, type, i, output );
                }

                update_ui( scheme, callback );

            });
        }

    };

    update_ui = function( result, callback )
    {

        $( '.appTitleText' ).css( 'background', '-webkit-linear-gradient( 45deg, ' + result.config.startColor + ', ' + result.config.endColor + ')' );
        $( '.appTitleText' ).css( '-webkit-background-clip', 'text' );
        $( '.appTitleText' ).css( '-webkit-text-fill-color', 'transparent' );

        var startCol = result.config.startColor, endCol = result.config.endColor
        var midCol = result.result[ Math.floor( result.result.length / 2 ) ].hex;
        var appIconSvg = template_appSVGbackground.replace( '{hex1}', startCol.replace( '#','') ).replace( '{hex2}', midCol.replace( '#','') ).replace( '{hex3}', endCol.replace( '#','') );

        $( '.appIcon' ).css( 'background-image', 'url("' + appIconSvg + '")' );
        console.log( 'url("' + appIconSvg + '")' );

        setTimeout( function(){
            $( 'div.appLayout' ).css( 'height', '98vh' );
        }, 500 );

        if ( callback ) callback();

    }

    jQuery( document ).ready(function () {

        $( 'div.appLayout' ).css( 'height', '100vh' );

        /* LAST USED BLEND COMBINATIONS */
        if ( localStorage.getItem( 'colorBlend_start' ) ) $( '.startColor' ).val( localStorage.getItem( 'colorBlend_start' ) );
        if ( localStorage.getItem( 'colorBlend_end' ) ) $( '.endColor' ).val( localStorage.getItem( 'colorBlend_end' ) );
        if ( localStorage.getItem( 'colorBlend_rows' ) ) $( '.colBlocks' ).val( localStorage.getItem( 'colorBlend_rows' ) );
        if ( localStorage.getItem( 'colorBlend_opacity' ) ) 
        {
            $( '.opac' ).val( localStorage.getItem( 'colorBlend_opacity' ) );
            $( '.opacText' ).html( localStorage.getItem( 'colorBlend_opacity' ) );

            run_Blend( 'table' );
        }

        run_createEvents();

    });

